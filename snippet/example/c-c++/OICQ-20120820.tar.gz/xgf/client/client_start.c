/*
 * Copyright (c) 2012  Xie Gaofeng
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *     Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *     Neither the name of the <ORGANIZATION> nor the names of its contributors
 *     may be used to endorse or promote products derived from this software
 *     without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <fcntl.h>
#include <pthread.h>
#include <limits.h>
#include <errno.h>
#include <unistd.h>
#include "../common/protocol.h"
#include "../common/user.h"
#include "../common/list.h"
#include "../common/tool.h"
#include "client_start.h"
#include "connect.h"

/*Define some environment variables in order to use the configure file later.*/
char SERVER_IP[17] = "192.168.0.112";  /* The  IP  of the server. */
int  SERVER_PORT = 7000;             /* The port of the server. */
/* The interval time of the heartbeat mechanism. */
int  HEARTBEAT_INTERVAL_TIME = 10; 
/* The port used to receive the datas which other client send. */
int  CLIENT_UDP_PORT         = 9000;

/* Define the global variable,
 * so that other threads and the functions use them.
 */
XList *user_list = NULL;

/* Stop:
 * Print the stop information and stop.
 */
void Stop(void)
{
  printf("Please Enter Any Key To Continue ...\n");
  while (getchar() != '\n');
}

/* show_help:
 * Print the usage when chat.
 */
void show_help(void)
{
  printf(HELP_INFO);
}

/* Start:
 * Start the program.
 */
void Start(int argc, char **argv)
{
  char choice = '0';
  int ret = 1;
  int sockfd;
  int FLAG = 1;
  
  if (argc > 3){
    printf("Usage:\n"
           "         client  [host_ip [host_port]]\n\n"
           "EXAMPLE: \n"
           "         client\n"
           "         client  127.0.0.1\n"
           "         client  127.0.0.1  8000\n");
    return;
  }
  else if (argc == 3){
    strncpy(SERVER_IP, *argv + 1, 16);
    SERVER_PORT = atoi(*argv + 2);
  }
  else if (argc == 2){
    strncpy(SERVER_IP, *argv + 1, 16);
  }
  else {
    FILE *file = fopen("client.config", "r");
    enfgets(SERVER_IP, 16, file);
    fscanf(file, "%d", &SERVER_PORT);
  }

  while (FLAG){
    system("clear");
    /* print the main interface. */
    printf(TOTAL_INTERFACE); 
    printf("Please input one digit(0-2): ");
    choice = getchar1();
    while (choice < '0' || choice > '2'){
      printf("Please input one digit(0-2): ");
      choice = getchar1();
    }

    /* According to your choice, execute the Register, Login, or Exit
     * operation.
     */
    switch (choice){
    case '1':   /* Register a user. */
      if ((ret = Register()) == 0){   /* Rigister fail. */
        printf("Register failed!\n");
        goto CONTINUE1;
      }
      else if (ret == -1){  /* A unexpected value. */
        printf("When register, a unexpected value occurs.\n");
        goto CONTINUE1;
      }
      else if (ret == -2){  /* A unexpected protocol. */
        printf("When register, read a unexpected protocol.\n");
        goto CONTINUE1;
      }
      printf("Register successfully!\n");
    CONTINUE1:
      Stop();
      break;
    case '2':   /* User login. */
      if ((ret = Login(&sockfd)) == 0){   /* Login fail. */
        printf("Login failed!\n");
        goto CONTINUE2;
      }
      else if (ret == -1){   /* A unexpected value. */
        printf("When Login, a unexpected value occurs.\n");
        goto CONTINUE2;
      }
      else if (ret == -2){  /* A unexpected protocol. */
        printf("When Login, read a unexpected protocol.\n");
        goto CONTINUE2;
      }

      /* Enter into chatting. */
      Chat(&sockfd);
      
    CONTINUE2:
      Stop();
      break;
    case '0':    /* Exit the program. */
      FLAG = 0;
      break;
    }
  }
}


/* Register:
 * Rigister a user.
 * RETURN:
 *       1 represents success.
 *       0 represents fail.
 *       -1 represents a unexpected value.
 *       -2 represents reading a unexpected protocol.
 */
int Register(void)
{
  int conn_sockfd;
  char username[10] = {0};
  char password[10] = {0};
  unsigned char data_send[20] = {0};
  unsigned char data_read[RECV_BUF_SIZE] = {0};
  protocol_t protocol = {0};
  int ret_w = 0;
  int ret_r = 0;

  printf("Please input the username(1-9 charactors): ");
  enfgets(username, 10, stdin);
  while (username[0] == '\0'){
    printf("Please input the username(1-9 charactors): ");
    enfgets(username, 10, stdin);
  }

  printf("Please input the password(1-9 charactors): ");
  enfgets(password, 10, stdin);
  while (password[0] == '\0'){
    printf("Please input the password(1-9 charactors): ");
    enfgets(password, 10, stdin);
  }

  /* Translate char to unsigned char to send datas.
   * The datas sent must be unsigned char.
   */
  char_to_uchar(data_send, username, 10);
  char_to_uchar(data_send + 10, password, 10);

  /* Create a socket which has connected to the server. */
  errno = 0;
  if (conn_to_server(&conn_sockfd) == -1){
    perror("conn_to_server");
    return 0;
  }

  /* send datas to the server to register the user. */
  errno = 0;
  if ((ret_w = send_data(conn_sockfd, REGISTER_PROTO, data_send, 20)) < 0){
    perror("Send to server");
    close(conn_sockfd);
    return 0;
  }
  else if (ret_w == 0){  /* This case should not occur. */
    printf("Send 0 charactor\n");
    close(conn_sockfd);
    return 0;
  }
  else if (ret_w < 6){ /*The protocol header isn't intact, but occurs rarely.*/
    printf("Send error, because the protocol header isn't intact.\n");
  }
  
  /* Read the information coming from the server and check whether register
     is successful.*/
  memset(&protocol, 0, sizeof(protocol));
  errno = 0;
  if ((ret_r = recv_data(conn_sockfd, data_read, &protocol)) < 0){
    perror("Receive from server");
    close(conn_sockfd);
    return 0;
  }
  else if (ret_r == 0 ){
    printf("Server closed!\n");
    close(conn_sockfd);
    return 0;
  }
  else if (ret_r < 6){
    printf("Receive error, because the protocol header having read isn't "
           "intact.\n");
    close(conn_sockfd);
    return 0;
  }

  /* Read ends and close the socket. */
  close(conn_sockfd);

  /* Judge whether the protocol is valid and the register is successful. */
  if (protocol.proto_type == REGISTER_PROTO){
    if (data_read[0] == 1) return 1;  /* Register successfully. */
    if (data_read[0] == 0) return 0;  /* Register failed. */
    return -1;     /* A unexpected value. */
  }
  else {
    return -2;    /* A unexpected protocol. */
  }
}

/* Login:
 * A user login into the server.
 * @c_sock: a pointer pointing to a socket file description used to save
 *          the socket file description connecting to the server.
 *          NOTICE: Only when login successfully, use it.
 * RETURN:
 *       1 represents success.
 *       0 represents fail.
 *       -1 represents a unexpected value.
 *       -2 represents reading a unexpected protocol.
 */
int Login(int *c_sockfd)
{
  int conn_sockfd;
  char username[10] = {0};
  char password[10] = {0};
  unsigned char data_send[20] = {0};
  unsigned char data_read[RECV_BUF_SIZE] = {0};
  protocol_t protocol = {0};
  int ret_w = 0;
  int ret_r = 0;

  printf("Please input the username(1-9 charactors): ");
  enfgets(username, 10, stdin);
  while (username[0] == '\0'){
    printf("Please input the username(1-9 charactors): ");
    enfgets(username, 10, stdin);
  }

  printf("Please input the password(1-9 charactors): ");
  enfgets(password, 10, stdin);
  while (password[0] == '\0'){
    printf("Please input the password(1-9 charactors): ");
    enfgets(password, 10, stdin);
  }

  /* Translate char to unsigned char to send datas.
   * The datas sent must be unsigned char.
   */
  char_to_uchar(data_send, username, 10);
  char_to_uchar(data_send + 10, password, 10);

  /* create a socket which has connecting the server. */
  errno = 0;
  if (conn_to_server(&conn_sockfd) == -1){
    perror("conn_to_server");
    return 0;
  }

  /* send datas to the server to verify whether the account and password 
     are valid. */
  errno = 0;
  if ((ret_w = send_data(conn_sockfd, LOGIN_PROTO, data_send, 
                         sizeof(data_send))) < 0){
    perror("Send to server");
    close(conn_sockfd);
    return 0;
  }
  else if (ret_w == 0){  /* This case should not occur. */
    printf("Send 0 charactor\n");
    close(conn_sockfd);
    return 0;
  }
  else if (ret_w < 6){/* The protocol header isn't intact, but occurs rarely.*/
    printf("Send error, because the protocol header isn't intact.\n");
  }

  /* Read the information coming from the server and check whether login
     is successful.*/
  memset(&protocol, 0, sizeof(protocol));
  errno = 0;
  if ((ret_r = recv_data(conn_sockfd, data_read, &protocol)) < 0){
    perror("Receive from server");
    close(conn_sockfd);
    return 0;
  }
  else if (ret_r == 0 ){
    printf("Server closed!\n");
    close(conn_sockfd);
    return 0;
  }
  else if (ret_r < 6){
    printf("Receive error, because the protocol header having read isn't "
           "intact.\n");
    close(conn_sockfd);
    return 0;
  }

  /* Judge whether the protocol is valid and the login is successful. */
  if (protocol.proto_type == LOGIN_PROTO){
    if (data_read[0] == 1){  /* Login successfully. */
      /* Save the socket. */
      *c_sockfd = conn_sockfd;
      return 1;
    }
    else if (data_read[0] == 0){ /* Login failed. */
      close(conn_sockfd);
      return 0;
    }
    close(conn_sockfd);
    return -1;             /* A unexpected value, and it shouldn't occur. */
  }
  else {
    close(conn_sockfd);
    return -2;            /* A unexpected protocol. */
  }
}

/* Chat:
 * Chat with other users, but it contains others, such as heartbeat mechanism.
 * @socket: a pointer pointing to the socket file description 
 *          connecting to the server.
 */
void Chat(int *sockfd)
{
  int FLAG = 1;
  char choice = '0';
  struct sockaddr_in destaddr;
  //struct sockaddr_in cliaddr;
  int sock_udp;
  char buf_send[1024] = {0};
  unsigned char datas_send[1024] = {0};
  char *head = NULL;
  char *tail = NULL;
  XList *userp;
  user_on user;
  int count = 0;
 
  pthread_t tid_recv_udp;
  pthread_t tid_online;
  pthread_t tid_heartbeat;

  /* Create the first thread, used to process the heartbeat mechanism. */
  errno = 0;
  if (pthread_create(&tid_heartbeat, NULL, (void *)t_heartbeat, sockfd) != 0){
    perror("pthread heartbeat");
    return;
  }

  /* Create the third thread, used to maintain the online user list coming
     from the server. */
  errno = 0;
  if (pthread_create(&tid_online, NULL, (void *)t_online, sockfd) != 0){
    perror("pthread online");
    if (pthread_cancel(tid_heartbeat) != 0)
      perror("cancel thread fail");
    return;    
  }

  /* create the UDP socket. */
  errno = 0;
  if ((sock_udp = socket(AF_INET, SOCK_DGRAM, 0)) == -1){
    perror("socket fail");
    pthread_cancel(tid_heartbeat);
    pthread_cancel(tid_online);
    x_list_free_full(user_list);
    Stop();
    return;
  }


  /* Create the third thread, used to listen the datas which other clients
   * send.
   */
  errno = 0;
  if (pthread_create(&tid_recv_udp, NULL, (void *)t_recv_udp, NULL) != 0){
    perror("pthread receive UDP");
    if (pthread_cancel(tid_heartbeat) != 0)
      perror("cancel thread fail");
    close(sock_udp);
    x_list_free_full(user_list);
    Stop();
    return;
  }

  /* chat cyclically. */ 
  while (FLAG){
    system("clear");
    printf(LOGIN_INTERFACE);     /* the interface when login successfully. */
    printf("Please input one digit(0-4): ");
    choice = getchar1();
    while (choice < '0' || choice > '4'){
      printf("Please input one digit(0-4): ");
      choice = getchar1();
    }
    switch (choice){
    case '1':    /* Show the information of all the online user. */
      show_all_online_user(user_list);
      Stop();
      break;
    case '2':   /* Chat with a other user. */
      /* chat with others continually. */
      while (1){
        /* Read the information chatting. */
        printf("You can send information(not more than 1000 charactors): \n");
        enfgets(buf_send, sizeof(buf_send), stdin);

        /* 'r' is a command, it return to the interface where login 
         * successfully. */
        if (buf_send[0] == 'r'){
          break;
        }

        /* 's' is a command, it will send the messages to others. */
        if (buf_send[0] == 's'){
          head = buf_send + 1;
          count = 0;
          int len_send;

          /* find user name, and copy it into user.name. */
          while (*head != '\0' && (*head == ' ' || *head == '\t')) ++head;
          tail = head;
          while (*tail != '\0' && (*tail != ' ' && *tail != '\t')){
            ++count;
            ++tail;
          }

          /* Only has the command or user name, not the messages. */
          if (*tail == '\0') goto ERROR; 
  
          /* The number of the charactors of user name is nine mostly. */
          if (count > 9){            
            char_to_uchar(user.name, head, 9);
            user.name[9] = '\0';
          }
          else {
            char_to_uchar_n(user.name, head, count);
            user.name[count] = '\0';
          }

          /* find messages sending, and copy it into datas_send. */
          head = tail;
          while (*head != '\0' && (*head == ' ' || *head == '\t')) ++head;
          /* Only has the command or user name, not the messages. */
          if (*head == '\0') goto ERROR;
          count = strlen(head);
          char_to_uchar_n(datas_send, head, count);
          datas_send[count] = '\0';

          /* find the user.name. */
          if ((userp = x_list_find(user_list, &user, compare_by_name)) == NULL){
            printf("The user [%s] isn't online.\n", user.name);
            continue;
          }

          /* send messages. */
          memset(&destaddr, 0, sizeof(destaddr));
          destaddr.sin_family = AF_INET;
          destaddr.sin_port = htons(CLIENT_UDP_PORT);
          destaddr.sin_addr.s_addr = htonl(((user_on *)(userp->data))->ip);

          errno = 0;
          if ((len_send = sendto_data(sock_udp, CLIENT_PROTO, datas_send, count + 1,
                          (struct sockaddr *)&destaddr, sizeof(destaddr))) < 0){
            perror("Send UPD datas fail");
            continue;
          }
          else if (len_send < 6){
            printf("Send the protocol header error\n");
            continue;
          }
          
          printf("Send successfully!\n");
          continue;
        }
      ERROR:
        printf("The command ERROR!\n");
        show_help();
      }
      break;
    case '3':   /* Show the usage when chat. */
      show_help();
      Stop();
      break;
    case '4':  /* Exit the current login and login again. */
    case '0':  /* Exit the program. */
      pthread_cancel(tid_heartbeat);
      pthread_cancel(tid_online);
      pthread_cancel(tid_recv_udp);
      close(*sockfd);
      close(sock_udp);
      x_list_free_full(user_list);
      if (choice == '4'){
        user_list = NULL;
        FLAG = 0;
        break;
      }
      else {
        exit(0);
      } /* if-else */
    } /* switch */
  }/* while */
} /* Chat */

/* show_all_online_user:
 * Print the information of all the online users.
 * @user_list: a pointer pointing to XList, saving the information of all 
 *             the online users.
 */
void show_all_online_user(XList *user_list)
{
  XList *p = user_list;
  unsigned int count = 1;
  if (p == NULL){
    printf("\nNO USER!!!\n\n");
  }
  while (p != NULL){
    printf("USER %u:\n", count++);
    printf("       user name: %s \n"
           "       IP       : %s \n",
           p->data->name, uint32_to_char(p->data->ip));
    p = p->next;
  }
}

/* t_recv_udp:
 * receive the datas which other clients send. It is a thread of "Chat". 
 * @sockfd: a pointer pointing to the socket file description.
 */
void * t_recv_udp(int *sockfd_udp)
{
  unsigned char data[1024];
  int sockfd;
  struct sockaddr_in cliaddr;
  protocol_t protocol = {0};
  int ret = 0;
  XList *userp = NULL;
  user_on user;
  socklen_t socklen = sizeof(cliaddr);


  /* create the UDP socket. */
  errno = 0;
  if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1){
    perror("socket fail");
    return NULL;
  }

  /* bind the socket to the local host and the port to listen to UDP datas. */
  memset(&cliaddr, 0, sizeof(cliaddr));
  cliaddr.sin_family = AF_INET;
  cliaddr.sin_addr.s_addr = INADDR_ANY;
  cliaddr.sin_port = htons(CLIENT_UDP_PORT);

  errno = 0;
  if (bind(sockfd, (struct sockaddr *)&cliaddr, sizeof(cliaddr)) != 0){
    perror("bind UDP socket to the local port");
    close(sockfd);
    return NULL; 
  }
  while (1){
    memset(data, 0, sizeof(data));
    /* receive messages. */
    errno = 0;
    if ((ret = recvfrom_data(sockfd, data, (struct sockaddr *)&cliaddr,
                             &socklen, &protocol)) < 0){
      perror("[recvfrom_data]receive UDP data");
      sleep(1);
      continue;
    }
    else if (ret == 0){
      perror("[recvfrom_data]NO DATA"); 
      sleep(1);
      continue;
    }
    else if (ret < 6){
      printf("Protocol header error!\n");
      sleep(1);
      continue;
    }
    
    /* Judge whether the protocol is valid. */
    if (protocol.proto_type == CLIENT_PROTO){
      user.ip = ntohl(cliaddr.sin_addr.s_addr);
      if ((userp = x_list_find(user_list, &user, compare_by_ip)) == NULL){
        printf("New Message [%s]: %s\n", uint32_to_char(user.ip), data);
        printf("[%s] isn't in the online user list!\n"
               "It maybe don't update the online user list! Please wait ... \n",
               uint32_to_char(user.ip));
        continue;
      }
      printf("New Message [from %s]: %s\n", userp->data->name, data);
    }
    else {
      printf("Receive a invalid protocol, and discard datas.\n");
    }
  }
}

/* t_online:
 * Maintain the online user list of the current client.
 * @sockfd: a pointer pointing to the socket file description connecting to
 *          the server. 
 */
void *t_online(int *sockfd)
{
  int ret;
  protocol_t protocol;
  int i = 0;
  user_on usr;
  unsigned char data[RECV_BUF_SIZE] = {0};

  /* Read the information of the online users from the server continually. */
  while (1){
    
    sleep(10);

    memset(data, 0, sizeof(data));
    memset(&protocol, 0, sizeof(protocol));
    
    /* Read the protocol to protocol and the first byte to len. */
    errno = 0;
    if ((ret = recv_data(*sockfd, data, &protocol)) < 0){
      perror("[online]Read from server");
      continue;
    }
    else if (ret == 0){
      printf("[online]The server closed!\n");
      continue;
    }
    else if (ret < 6){
      printf("[online]Read from server ERROR, because the protocol header is "
             "not intact.\n");
      continue;
    }

    /* Judge whether the protocol is valid. */
    if (protocol.proto_type == BROAT_PROTO){
      /* Release the old online user list in order to build the new. */
      x_list_free_full(user_list);
      user_list = NULL;

      /* Read each online user in order and  append them to user_list. */
      for (i = 1; i <= data[0] * 14; i += 14){
         /*the highest bit*/
        usr.ip =  data[i + 3] * num3;
        usr.ip += data[i + 2] * num2;
        usr.ip += data[i + 1] * num1;
        usr.ip += data[i];   /* the least bit  */
        memcpy(usr.name, data + i + 4, 10);
        user_list = x_list_prepend(user_list, &usr);
      } /* for */
    }
    else {
      printf("[online]Read an unexpected protocol from the server.\n");
    } /* if-else */
  } /* while */
} /* End of function */

/* t_heartbeat:
 * The heartbeat mechanisim, used to report the online state to the server.
 * @sockfd: a pointer pointing to the socket file description connecting to
 *          the server. 
 */
void *t_heartbeat(int *sockfd)
{
  int ret = 0;
  while (1){
    sleep(HEARTBEAT_INTERVAL_TIME);
    errno = 0;
    if ((ret = send_data(*sockfd, HEARTBEAT_PROTO, NULL, 0)) < 0){
      perror("[heartbeat]write to server");
    } /* if */
    else if (ret < 6){
      printf("Sending heartbeat failed, because the protocol header is not "
             "intact.\n");
    } /* if-else */
  } /* while */
} /* End of function */

