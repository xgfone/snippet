

#ifndef __CONNECT_H
#define __CONNECT_H

/* conn_to_server:
 * Create a socket connecting to the server.
 * RETURN: the socket file description. If fail, return -1.
 */
int conn_to_server(int *sock);

#endif  /* __CONNECT_H */
