

#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include "client_start.h"
#include "connect.h"
/* conn_to_server:
 * Create a socket connecting to the server.
 * RETURN: the socket file description. If fail, return -1.
 */
int conn_to_server(int *sock){
  struct sockaddr_in servaddr;
  int sockfd;
  if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0){
    return -1;
  }
  memset(&servaddr, 0, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  if (inet_pton(AF_INET, SERVER_IP, &servaddr.sin_addr.s_addr) <= 0){
    close(sockfd);
    return -1;
  }
  servaddr.sin_port = htons((uint16_t)SERVER_PORT);

  if (connect(sockfd, (struct sockaddr *)&servaddr,
              sizeof(servaddr)) != 0){
    close(sockfd);
    return -1;
  }
  if (sock != NULL)  *sock = sockfd;
  return sockfd;
}
