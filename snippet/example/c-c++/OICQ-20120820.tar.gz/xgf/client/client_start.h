/*
 * Copyright (c) 2012  Xie Gaofeng
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *     Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *     Neither the name of the <ORGANIZATION> nor the names of its contributors
 *     may be used to endorse or promote products derived from this software
 *     without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __CLIENT_H
#define __CLIENT_H

#include <stdio.h>

#include "../common/user.h"
#include "../common/list.h"

#define TOTAL_INTERFACE "            You can operate:\n"\
                        "             1. Register\n"\
                        "             2. Login\n"\
                        "             0. Exit\n\n"

#define LOGIN_INTERFACE "             YOU LOGIN SUCCESSFULLY\n"\
                        "        You can operate:\n"\
                        "         1. Show all the online users\n"\
                        "         2. Choose a user to chat with\n"\
                        "         3. Show the help information about chat\n"\
                        "         4. Login again\n"\
                        "         0. Exit\n"

#define HELP_INFO       "\n"\
                        "        USAGE:\n"\
                        "             Command  [User  Messages] \n"\
                        "\n"\
                        "        THEREINTO:\n"\
                        "             Command has \"s\" and \"r\".\n"\
                        "                 \"s\" is used to send messages to user; \n"\
                        "                 \"r\" is used to return to the previous interface.\n"\
                        "             User: the name of the online user, "\
                        "to which you will send messages.\n"\
                        "             Messages: the information which you send to User.\n"\
                        "\n"\
                        "        EXAMPLE: \n"\
                        "             s   aaron  hello\n"\
                        "             r\n"\
                        "\n"


extern char SERVER_IP[];
extern int SERVER_PORT;

/* the list to save the online user. */
extern XList *user_list;

/* Stop:
 * Print the stop information and stop.
 */
void Stop(void);

/* show_help:
 * Print the usage when chat.
 */
void show_help(void);

/* Start:
 * Start the program.
 */
void Start(int argc, char **argv);

/* Register:
 * Rigister a user.
 * RETURN:
 *       1 represents success.
 *       0 represents fail.
 *       -1 represents a unexpected value.
 *       -2 represents reading a unexpected protocol.
 */
int Register(void);

/* Login:
 * A user login into the server.
 * @c_sock: a pointer pointing to a socket file description used to save
 *          the socket file description connecting to the server.
 *          NOTICE: Only when login successfully, use it.
 * RETURN:
 *       1 represents success.
 *       0 represents fail.
 *       -1 represents a unexpected value.
 *       -2 represents reading a unexpected protocol.
 */
int Login(int *c_sockfd);


/* Chat:
 * Chat with other users, but it contains others, such as heartbeat mechanism.
 * @socket: a pointer pointing to the socket file description 
 *          connecting to the server.
 */
void Chat(int *sockfd);

/* t_recv_udp:
 * receive the datas which other clients send. It is a thread of "Chat". 
 * @sockfd: a pointer pointing to the socket file description.
 */
void *t_recv_udp(int *sockfd_udp);

/* t_online:
 * Maintain the online user list of the current client.
 * @sockfd: a pointer pointing to the socket file description connecting to
 *          the server. 
 */
void *t_online(int *sockfd);

/* t_heartbeat:
 * The heartbeat mechanisim, used to report the online state to the server.
 * @sockfd: a pointer pointing to the socket file description connecting to
 *          the server. 
 */
void *t_heartbeat(int *sockfd);

/* show_all_online_user:
 * Print the information of all the online users.
 * @user_list: a pointer pointing to XList, saving the information of all 
 *             the online users.
 */
void show_all_online_user(XList *user_list);


#endif  /* __CLIENT_H */
