

#include "server_start.h"

int main(int argc, char **argv)
{
  Start();
  return 0;
}
