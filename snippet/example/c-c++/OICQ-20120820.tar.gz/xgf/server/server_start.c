/*
 * Copyright (c) 2012  Xie Gaofeng
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *     Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *     Neither the name of the <ORGANIZATION> nor the names of its contributors
 *     may be used to endorse or promote products derived from this software
 *     without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <fcntl.h>
#include <pthread.h>
#include <limits.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/select.h>
#include <errno.h>
#include <time.h>
#include <signal.h>
#include <sys/wait.h>
#include "../common/user.h"
#include "../common/list.h"
#include "../common/tool.h"
#include "server_start.h"

#ifdef DAEMON_
#include <syslog.h>
#endif

/*Define some environment variables in order to use the configure file later */
/* The port which the server uses it to listen the coming of the client. */
int SERVER_PORT          = 6000; 
/* This file is used to save the accounts and passwords. */
char PASSWORD_FILENAME[]   = "/tmp/OICQ_password.txt";
/* Default online time. The unit is second.
 * If Out of this time, think that this use is outline.
 */
int DEFAULT_ONLINE_TIME  = 30;
/* The server check the online user list, and judge whether the users are 
 * outline, per this time. If outline, delete he or she from the online user
 * list. The unit is second. 
 */
int TIME_LOOP_SLEEP_TIME = 20;
/* The server will send the online user list to all the online user per this 
 * time. The unit is second.
 */
int BROAT_SLEEP_TIME     = 20;


/* Define some global variables,
 * so that other threads and the functions use them.
 */
fd_set rset;
fd_set set;
int maxfd = 0;
int request_sock;
unsigned int ip_addr[1024] = {0};
XList *user_list = NULL;

void Start(void)
{
  protocol_t protocol = {0};
  struct sockaddr_in servaddr = {0};
  struct sockaddr_in remote = {0};
  uint32_t addrlen;
  int new_sock;
  int nfound;
  int fd;
  int bytes;
  FILE *file = NULL;
  struct timeval timeout;
  
  char buf[BUF_SIZE] = {0};
  unsigned char buf_uchar[BUF_SIZE] = {0};
  char account[ACCOUNT_LINE_SIZE] = {0};
  char buf_write[30] = {0};
  unsigned char is_success = 1;
  char *p = NULL;
  size_t buf_real_len = 0;
  
  pthread_t tid_broat;
  pthread_t tid_time;
  
#ifdef DAEMON_
  pid_t pid;
#endif
  
  XList *userp = NULL;
  user_on user = {0};
  
  /* Install some functions to handle the signals. */
  signal(SIGTERM, handle_sig);
  signal(SIGINT,  handle_sig);
  signal(SIGCHLD, handle_sig);
  signal(SIGHUP,  handle_sig);
  signal(SIGQUIT, handle_sig);
  signal(SIGABRT, handle_sig);

  /* If the password file doesn't exist, create it. */ 
  if (access(PASSWORD_FILENAME, F_OK) != 0){
    int create_fd;
    char buf = '#';
    if ((create_fd = open(PASSWORD_FILENAME, O_RDWR | O_CREAT, 0600)) == -1){
      fprintf(stderr, "The password file doesn't exist, "
                      "but it failed when created it.\n"
                      "REASON: %s\n", strerror(errno));
      exit(1);
    }
    write(create_fd, &buf, sizeof(buf));
    close(create_fd);
  }

#ifdef DAEMON_
  /* create the daemon process. */
  
  /* Change the current working directory to the root("/"). */
  chdir("/");
  
  /* Clear the file creation mask. */
  umask(0);
  
  /* Create a child process. */
  errno = 0;
  if ((pid = fork()) == -1){
    perror("Fork fails");
    exit(1);
  }
  else if (pid != 0){
    exit(0);
  }
  
  /* The following is into the child which the first "fork()" creates. */
  /* Become the session leader to lose the controlling TTY. */
  setsid();
  
  /* Create the child process secondly to ensure future opens won't allocate
   * controlling TTY.
   */
  errno = 0;
  if ((pid = fork()) == -1){
    perror("Fork fails");
    exit(1);
  }
  else if (pid != 0){
    exit(0);
  }
  
  /* close all the file descriptions(0, 1, 2). */
  close(0);
  close(1);
  close(2);
  
  /* Initialize the log file. */
  openlog("OICQ", LOG_CONS | LOG_PID, LOG_DAEMON);
#endif /* DAEMON_ */
   
  /* Create a pthread to process the broatcast. */
  errno = 0;
  if (pthread_create(&tid_broat, NULL, (void *)t_broat, NULL) != 0){
#ifdef DAEMON_
    syslog(LOG_ERR, "pthread broat: %s\n", strerror(errno));
    closelog();
#else
    perror("pthread broat");
#endif
    exit(1);
  }

  /* Create a pthread to check whether the users are out of time.
   * If out of time, think that he has been outline.
   */
  errno = 0;
  if (pthread_create(&tid_time, NULL, (void *)t_time, NULL) != 0){
#ifdef DAEMON_
    syslog(LOG_ERR, "pthread time: %s\n", strerror(errno));
    closelog();
#else
    perror("pthread time");
#endif
    pthread_cancel(tid_broat);
    exit(1);
  }

  /* Create a socket to listen the connections of the users. */
  errno = 0;
  if ((request_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
#ifdef DAEMON_
    syslog(LOG_ERR, "socket: %s\n", strerror(errno));
    closelog();
#else
    perror("socket");
#endif
    exit(1);
  }

  /* Set the information of the host where the server is, in order that
   * the socket can be bind onto it. */
  memset(&servaddr, 0, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  /*servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); */
  servaddr.sin_addr.s_addr = INADDR_ANY;
  servaddr.sin_port = htons((uint16_t)SERVER_PORT);

  /* Bind the socket onto the address of the host. */
  errno = 0;
  if (bind(request_sock, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0){
#ifdef DAEMON_
    syslog(LOG_ERR, "bind: %s\n", strerror(errno));
    closelog();
#else
    perror("bind");
#endif
    close(request_sock);
    exit(1);
  }

  /* Let the socket to listen the connections of the users. */
  errno = 0;
  if (listen(request_sock, 5) < 0){
#ifdef DAEMON_
    syslog(LOG_ERR, "listen: %s\n", strerror(errno));
    closelog();
#else
    perror("listen");
#endif
    close(request_sock);
    exit(1);
  }

  /* Initializate the configure for "select". */
  FD_ZERO(&set);
  FD_SET(request_sock, &set);
  maxfd = request_sock;

#ifndef DAEMON_
  printf("The server has started successfully, and wait to connect ...\n");
#endif

  while (1){
    rset = set;
    timeout.tv_sec = 1;
    timeout.tv_usec = 0;

    errno = 0;
    if ((nfound = select(maxfd + 1, &rset, NULL, NULL, &timeout)) < 0){
#ifdef DAEMON_
      syslog(LOG_ERR, "select: %s\n", strerror(errno));
#else
      perror("[Start]select");
#endif    
      goto ERROR;
    }
    else if (nfound == 0){  /* select is out of time. */
#ifndef DAEMON_
      printf(".");
      fflush(stdout);
#endif
      continue;
    }

    /* Check whether "request_sock" is active.
     * If it is active, connect it.
     */
    if (FD_ISSET(request_sock, &rset)){
      addrlen = sizeof(remote);
      errno = 0;
      if ((new_sock = accept(request_sock, (struct sockaddr *)&remote,
                             &addrlen)) < 0){
#ifdef DAEMON_
        syslog(LOG_ERR, "accept: %s\n", strerror(errno));
#else
        perror("accept");
#endif
        FD_CLR(fd, &rset);
        goto FD;
      }

      ip_addr[new_sock]  = ntohl((uint32_t)remote.sin_addr.s_addr);
#ifdef DAEMON_
      syslog(LOG_ERR, "Connection from host %s, port %d, socket %d\n",
             inet_ntoa(remote.sin_addr), ntohs(remote.sin_port), new_sock);
#else
      printf("Connection from host %s, port %d, socket %d\n",
             inet_ntoa(remote.sin_addr), ntohs(remote.sin_port), new_sock);
#endif

      /* Add the new connection into "set", not "rset", in order to listen it
       * next.
       */
      FD_SET(new_sock, &set);
      if (new_sock > maxfd)
        maxfd = new_sock;
      FD_CLR(request_sock, &rset);
      --nfound;
    }

  FD:
    /* Loop to check whether other sockets are active, and process it. */
    for (fd = 0; fd <= maxfd && nfound > 0; ++ fd){
      if (FD_ISSET(fd, &rset)){
        --nfound;
        memset(buf_uchar, 0, BUF_SIZE);
        errno = 0;
        if ((bytes = recv_data(fd, buf_uchar, &protocol)) < 0){
#ifdef DAEMON_
          syslog(LOG_ERR, "read: %s\n", strerror(errno));
#else
          perror("read");
#endif
          continue;
        }
        else if (bytes == 0){  /* The client is closed. */
#ifdef DAEMON_
          syslog(LOG_INFO, "One user is outline.\n");
#else
          printf("One user is outline.\n");
#endif
          FD_CLR(fd, &set);
          close(fd);
          
          /* Delete the node whose "ip" member is equal to ip_addr[fd] */
          user.ip = ip_addr[fd];
          if ((userp = x_list_find(user_list, &user, compare_by_ip)) != NULL){
            XList *q = userp;
            userp = x_list_prev(user_list, userp);
            user_list = x_list_free_from_list(user_list, q);
          }
          ip_addr[fd] = 0;
          
          continue;
        }
        else if (bytes < 6){
#ifdef DAEMON_
          syslog(LOG_ERR, "Read a wrong protocol header.\n");
#else
          perror("Read a wrong protocol header.\n");
#endif
          continue;
        }

        /* Translate unsigned char to char, in order that the standart C
         * library process it.
         */
        uchar_to_char_n(buf, buf_uchar, BUF_SIZE);
        
        /* According to the type of the protocol, execute the various
         * operations.
         */
        switch (protocol.proto_type){
        case REGISTER_PROTO:
          is_success = 1;
          errno = 0;
          /* Open the password file, check whether the account exists.
           * NOTICE: the password file allow the blank, so must skip it.
           */
          if ((file = fopen(PASSWORD_FILENAME, "r")) != NULL){
            while(enfgets(account, ACCOUNT_LINE_SIZE, file) != NULL){
              /* In the password file, the line beginning with '#' or ';' is
               * thought of the comment, and ignored.
               */
              if (account[0] == '#' || account[0] == ';') continue;
              p = account;
              /* Find the first charactor of the account ID. */
              while ((*p != '\0') && (*p == ' ' || *p == '\t'))  ++p;
              if (*p == '\0')  continue;
              /* Count the number of the charactors of the account. */
              buf_real_len = 0;
              while ((*p != '\0') && (*p != ' ') && (*p != '\t')){
                ++buf_real_len;
                ++p;
              }
              if (strncmp(buf, p - buf_real_len, buf_real_len) == 0){
                is_success = 0;
                break;
              }
            } /* while */
            fclose(file);
          } /*  if */
          else {  /* Open fails. And think that the verification fails. */
#ifdef DAEMON_
            syslog(LOG_ERR, "[Register]fopen fail: %s\n", strerror(errno));
#else
            perror("[Register]fopen fail");
#endif
            is_success = 0;
          }

          /* If success, write the account and the password into the file. */
          if (is_success == 1){ /* success */
            errno = 0;
            if ((file = fopen(PASSWORD_FILENAME, "a")) == NULL){
#ifdef DAEMON_
              syslog(LOG_ERR, "[Register]fopen fail: %s\n", strerror(errno));
#else
              perror("[Register]fopen fail");
#endif
              is_success = 0;
            }
            else {
              buf[9] = '\0';
              buf[19] = '\0';
              bytes = sprintf(buf_write, "%s", buf);
              sprintf(buf_write + bytes, "    %s\n", buf + 10);
              fputs(buf_write, file);
              fclose(file);
            }
          }

          /* Record the successful or failing information. */
          if (is_success == 1){
#ifdef DAEMON_
            syslog(LOG_INFO, "[IP: %s] registers successfully!\n"
                             "Register account: %s\n",
                   uint32_to_char(ip_addr[fd]), buf);
#else
            printf("[IP: %s] registers successfully!\n", 
                   uint32_to_char(ip_addr[fd]));
            printf("Register account: %s\n", buf);
#endif
          }
          else {
#ifdef DAEMON_
            syslog(LOG_INFO, "[IP: %s] registers unsuccessfully!\n", 
                   uint32_to_char(ip_addr[fd]));
#else
            printf("[IP: %s] registers unsuccessfully!\n", 
                   uint32_to_char(ip_addr[fd]));
#endif
          }
          
          /* Send success or failure messages to the client. */
          errno = 0;
          if ((bytes = send_data(fd, REGISTER_PROTO, &is_success, 1)) < 0){
#ifdef DAEMON_
            syslog(LOG_ERR, "[Register] send data to [IP: %s] fail: %s\n",
                   uint32_to_char(ip_addr[fd]), strerror(errno));
#else
            fprintf(stderr, "[Register] send data to [IP: %s] fail: %s\n",
                    uint32_to_char(ip_addr[fd]), strerror(errno));
#endif
          }
          else if (bytes < 6){
#ifdef DAEMON_
            syslog(LOG_DEBUG, "[Register]Send success or failure error! "
                              "Because sending the protocol header error.\n");
#else 
            fprintf(stderr, "[Register]Send success or failure error! "
                            "Because sending the protocol header error.\n");
#endif
          }
          FD_CLR(fd, &set);
          close(fd);
          ip_addr[fd] = 0;
          break;
        case LOGIN_PROTO:
          is_success = 0;
          /* Open the password file, check whether the account exists.
           * If exists, judge whether the password is exact.
           * If exact, Login is successful; or, unsuccessful.
           * NOTICE: the password file allow the blank, so must skip it.
           */
          errno = 0;
          if ((file = fopen(PASSWORD_FILENAME, "r")) != NULL){
            while(enfgets(account, ACCOUNT_LINE_SIZE, file) != NULL){
              /* In the password file, the line beginning with '#' or ';' is
               * thought of the comment, and ignored.
               */
              if (account[0] == '#' || account[0] == ';') continue;
              p = account;
              /* Find the first charactor of the account ID, and check whether
               * this account is that of login.
               */
              while ((*p != '\0') && (*p == ' ' || *p == '\t'))  ++p;
              if (*p == '\0') continue;
              
               /* Count the number of the charactors of the account. */
              buf_real_len = 0;
              while ((*p != '\0') && (*p != ' ') && (*p != '\t')){
                ++buf_real_len;
                ++p;
              }
              if (strncmp(buf, p - buf_real_len, buf_real_len) != 0)  continue;

              /* Skip the blank and find the first charactor of the password. */
              /* Find the first blank charactor. */
              while ((*p != '\0') && (*p != ' ') && (*p != '\t')){
                ++p;
              }
              /* Find the first non-blank charactor after the blank charactor.*/
              while ((*p != '\0') && (*p == ' ' || *p == '\t')) ++p;
              /* Don't have the password. */
              if (p == '\0')   continue;
              
               /* Count the number of the charactors of the password. */
              buf_real_len = 0;
              while ((*p != '\0') && (*p != ' ') && (*p != '\t')){
                ++buf_real_len;
                ++p;
              }
              /* The account and the password are valid. */
              if (strncmp(buf + 10, p - buf_real_len, buf_real_len) == 0){
                is_success = 1;
                break;                
              } 
            } /* while */
            fclose(file);
          }
          else {
#ifdef DAEMON_
            syslog(LOG_ERR, "[Login]fopen fail: %s\n", strerror(errno));
#else
            perror("[Login]fopen fail");
#endif
          }

          /* Send success or failure messages to the client. */
          errno = 0;
          if ((bytes = send_data(fd, LOGIN_PROTO, &is_success, 1)) < 0){
#ifdef DAEMON_
            syslog(LOG_ERR, "[Login] Send data to [IP: %s] fail: %s\n",
                   uint32_to_char(ip_addr[fd]), strerror(errno));
#else
            fprintf(stderr, "[Login] Send data to [IP: %s] fail: %s\n",
                    uint32_to_char(ip_addr[fd]), strerror(errno));
#endif
            
          }
          else if (bytes < 6){
#ifdef DAEMON_
            syslog(LOG_DEBUG, "[Login] Send success or failure error! "
                              "Because sending the protocol header error.\n");
#else
            fprintf(stderr, "[Login] Send success or failure error! "
                            "Because sending the protocol header error.\n");
#endif
          }

          /* Record the successful or failing information.
           * If fail, close the socket.
           */
          if (is_success == 1 && bytes > 6){
            memcpy(user.name, buf_uchar, 10);
            user.ip = ip_addr[fd];
            user.time = time(NULL);
            user_list = x_list_prepend(user_list, &user);

#ifdef DAEMON_
            syslog(LOG_INFO, "(fd: %d)-(IP: %s) login successfully!\n" 
                             "Login account: %s\n", 
                   fd, uint32_to_char(ip_addr[fd]), buf);
#else
            printf("(fd: %d)-(IP: %s) login successfully!\n", 
                   fd, uint32_to_char(ip_addr[fd]));
            printf("Login account: %s\n", buf);
#endif
          }
          else {
            FD_CLR(fd, &set);
            close(fd);
#ifdef DAEMON_
            syslog(LOG_INFO, "(fd: %d)-(IP: %s) login unsuccessfully!\n", 
                   fd, uint32_to_char(ip_addr[fd]));
#else
            printf("(fd: %d)-(IP: %s) login unsuccessfully!\n", 
                   fd, uint32_to_char(ip_addr[fd]));
#endif
            ip_addr[fd] = 0;
          }
          
          break;
        case HEARTBEAT_PROTO:
          /* If ip_addr[fd] is equal to 0, the user whose socket is fd isn't
           * online. But this case shouldn't occur rarely.
           */
          if (ip_addr[fd] == 0) {
            FD_CLR(fd, &set);
            close(fd);
            break;
          }

#ifndef DAEMON_
          printf("\nReceive the heartbeat from (fd: %d)-(IP: %s).\n",
                 fd, uint32_to_char(ip_addr[fd]));
#endif
         

          /* Find the user whose IP is ip_addr[fd]. If found, set his or her
           * time to the current time.
           */
          user.ip = ip_addr[fd];
          if ((userp = x_list_find(user_list, &user, compare_by_ip)) == NULL){
#ifdef DAEMON_
            syslog(LOG_ERR, "[Heartbeat] Not found the user whose IP is %s\n", 
                   uint32_to_char(ip_addr[fd]));
#else
            fprintf(stderr, "[Heartbeat] Not found the user whose IP is %s\n", 
                    uint32_to_char(ip_addr[fd]));
#endif
          }
          else {
            /* Use the timporary variable in order that the system doesn't
             * change the old time if getting the system time fails.
             */
            time_t tmp_time = 0;
            errno = 0;
            if ((tmp_time = time(NULL)) == (time_t)(-1)){
#ifdef DAEMON_
              syslog(LOG_ERR, "[Heartbeat] time fail: %s\n", strerror(errno));
#else
              perror("[Heartbeat] time fail");
#endif
            }
            else {
              userp->data->time = tmp_time;
            } /*  if-else */
          } /* if-else */
          break;
        default :
#ifdef DAEMON_
          syslog(LOG_WARNING, 
                 "Receive a unexpected protocol from \n");
#else
          printf("Receive a unexpected protocol from \n");
#endif
          
          if (ip_addr[fd] != 0){
#ifdef DAEMON_
            syslog(LOG_WARNING, "[IP: %s].\n", uint32_to_char(ip_addr[fd]));
#else
            printf("[IP: %s].\n", uint32_to_char(ip_addr[fd]));
#endif
            
          }
          else {
#ifdef DAEMON_
            syslog(LOG_WARNING, "[fd: %d].\n", fd);
#else
            printf("[fd: %d].\n", fd);
#endif
          }
        } /* switch */ 
      } /* if */
    } /* for */
  } /* while */
 ERROR:
  pthread_cancel(tid_broat);
  pthread_cancel(tid_time);
  close(request_sock);  /* don't accept connection. */
  for (fd = 0; fd <= maxfd; ++fd) close(fd); /* close all the connections. */
  x_list_free_full(user_list);  /* clean the online use list. */

#ifdef DAEMON_
  closelog();
#endif
} /* end of function */

void handle_sig(int sig)
{
  /* Ignore SIGCHLD */
  if (SIGCHLD == sig){
    while (waitpid(-1, NULL, WNOHANG) > 0) ;
    return; 
  }
  
  /* Read the configure file again. */
  if (SIGHUP == sig){
    return;
  }

  /* Clean and exit the program. */
  if (SIGTERM == sig || SIGINT == sig || SIGABRT == sig || SIGQUIT == sig){
    int i;
    int max = maxfd;
    for (i = 0; i <= max; ++i)
      close(request_sock);
    x_list_free_full(user_list);
#ifdef DAEMON_
    syslog(LOG_DEBUG, "The server exit because of receiving signal %d\n", sig);
    closelog();
#else
    printf("The server exit because of receiving signal %d\n", sig);
#endif
    exit(0);
  }
}

void t_broat(void)
{
  int fd;
  unsigned char data_send[BUF_SIZE] = {0};
  XList *userp = user_list;
  size_t count = 0;
  
  int ret_len = 0;

  while (1){
    sleep(BROAT_SLEEP_TIME);

    if (user_list == NULL) continue;

    userp = NULL;
    count = 1;
    while ((userp = x_list_next(user_list, userp)) != NULL){
      data_send[count++] = (unsigned char)(userp->data->ip % num1);
      data_send[count++] = (unsigned char)((userp->data->ip % num2) / num1);
      data_send[count++] = (unsigned char)((userp->data->ip % num3) / num2);
      data_send[count++] = (unsigned char)(userp->data->ip / num3);
      memcpy(data_send + count, userp->data->name, 10);
      count += 10;
    }
    data_send[0] = (unsigned char)(count / 14);
    
    for (fd = 0; fd <= maxfd; ++fd){
      if (FD_ISSET(fd, &set) && fd != request_sock){
        errno = 0;
        if ((ret_len = send_data(fd, BROAT_PROTO, data_send, count)) < 0){
#ifdef DAEMON_
          syslog(LOG_ERR, "[Broat]send data to (fd: %d)-(IP: %s) fail: %s\n", 
                 fd, uint32_to_char(ip_addr[fd]), strerror(errno));
#else
          fprintf(stderr, "[Broat]send data to (fd: %d)-(IP: %s) fail: %s\n", 
                  fd, uint32_to_char(ip_addr[fd]), strerror(errno));
#endif
          
        }  /* if */
      } /* if */
    }  /* for */
  } /* while */
} /* end of function */

void t_time(void)
{
  XList *userp = NULL;
  XList *q = NULL;
  time_t now = 0;
  int fd = 0;
  int max = 0;

  while (1) {
    sleep(TIME_LOOP_SLEEP_TIME);
    errno = 0;
    if ((now = time(NULL)) == (time_t)(-1)){
#ifdef DAEMON_
      syslog(LOG_ERR, "[Time] time() fail: %s\n", strerror(errno));
#else
      perror("[Time] time() fail");
#endif
      
      continue;
    }
    max = maxfd;
    userp = NULL;
    while ((userp = x_list_next(user_list, userp)) != NULL){

      /* Out of time, and think it of exit. */
      if (difftime(now, userp->data->time) > (double)DEFAULT_ONLINE_TIME){ 
        /* find the socket file description corresponding to 
           userp->data->time */
        for (fd = 0; fd <= max; ++fd){
          if (ip_addr[fd] == userp->data->ip) break;
        }
        
         /* found the socket. */
        if (fd <= max){ 
          FD_CLR(fd, &set);
          close(fd);
          ip_addr[fd] = 0;
          q = userp;
          userp = x_list_prev(user_list, userp);
          user_list = x_list_free_from_list(user_list, q);
#ifndef DAEMON_          
          printf("[IP: %s] is out of time.\n", uint32_to_char(ip_addr[fd]));
#endif
        }
        else {  /* didn't find the socket. */
#ifdef DAEMON_
          syslog(LOG_DEBUG,
                 "[Time] It doesn't have socket to  match with (IP: %s)\n",
                 uint32_to_char(userp->data->ip));
#else
          fprintf(stderr, 
                  "[Time] It doesn't have socket to  match with (IP: %s)\n",
                  uint32_to_char(userp->data->ip));
#endif
        }
      } /* if */
    } /* while */
  } /* while */
} /* end of function */

