/*
 * Copyright (c) 2012  Xie Gaofeng
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *     Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *     Neither the name of the <ORGANIZATION> nor the names of its contributors
 *     may be used to endorse or promote products derived from this software
 *     without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <string.h>
#include "tool.h"

/* Define the number value of two bytes and three bytes in order to use. */
unsigned int num1 = UCHAR_MAX + 1;
unsigned int num2 = (UCHAR_MAX + 1) * (UCHAR_MAX + 1);
unsigned int num3 = (UCHAR_MAX + 1) * (UCHAR_MAX + 1) * (UCHAR_MAX + 1);

unsigned char * char_to_uchar(unsigned char *dest, const char *src, size_t n)
{
    size_t i = 0;
    unsigned char *p = dest;
    const char *q = src;
    size_t count = n - 1;
    if (dest == NULL || src == NULL || n == 0) return NULL;
    while ((i < count) && (*q != '\0')){
        *p = (unsigned char)*q;
        ++i;
        ++p;
        ++q;
    }
    *p = '\0';
    return dest;
}

unsigned char * char_to_uchar_n(unsigned char *dest, const char *src, size_t n)
{
    size_t i = 0;
    unsigned char *p = dest;
    const char *q = src;
    if (dest == NULL || src == NULL || n == 0) return NULL;
    while (i < n){
        *p = (unsigned char)*q;
        ++i;
        ++p;
        ++q;
    }
    return dest;
}

char * uchar_to_char(char *dest, const unsigned char *src, size_t n)
{
    size_t i = 0;
    char *p = dest;
    const unsigned char *q = src;
    size_t count = n - 1;
    if (dest == NULL || src == NULL || n == 0) return NULL;
    while ((i < count) && (*q != '\0')){
        *p = (char)*q;
        ++i;
        ++p;
        ++q;
    }
    *p = '\0';
    return dest;
}

char * uchar_to_char_n(char *dest, const unsigned char *src, size_t n)
{
    size_t i = 0;
    char *p = dest;
    const unsigned char *q = src;
    if (dest == NULL || src == NULL || n == 0) return NULL;
    while (i < n){
        *p = (char)*q;
        ++i;
        ++p;
        ++q;
    }
    return dest;
}


void putus(const unsigned char *str)
{
    while (*str != '\0'){
        putchar(*str);
        ++str;
    }
}

char UINT32_TO_CHAR[17] = {0};
char *uint32_to_char(unsigned int ip)
{
  unsigned int s1 = ip % num1;
  unsigned int s2 = ip % num2 / num1;
  unsigned int s3 = ip % num3 / num2;
  unsigned int s4 = ip / num3;
  sprintf(UINT32_TO_CHAR, "%u.%u.%u.%u", s4, s3, s2, s1);
  return UINT32_TO_CHAR;

}


/* getchar1:
* Read a line, but fetch the first charactor except the newline.
* If not satisfy, read continually.
*/
int getchar1(void)
{
    int ret = getchar();
    if (ret != '\n')
        while (getchar() != '\n') ;
        return ret;
}

/* enfgets:
* The enhenced version of fgets in the C standart library. enfgets is similar
* to fgets, except that enfgets will discard the newline, if exists.
*/
char *enfgets(char *buf, int n, FILE *stream)
{
    size_t len = 0;
    if (buf == NULL || stream == NULL || n < 1) return NULL;
    if (fgets(buf, n, stream)== NULL) return NULL;
    len = strlen(buf);
    if (buf[len - 1] == '\n')
        buf[len - 1] = '\0';
    else {
        while(getchar() != '\n');
    }
    return buf;
}
