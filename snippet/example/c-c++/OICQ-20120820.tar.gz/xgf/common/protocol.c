/*
 * Copyright (c) 2012  Xie Gaofeng
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *     Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *     Neither the name of the <ORGANIZATION> nor the names of its contributors
 *     may be used to endorse or promote products derived from this software
 *     without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <limits.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <syslog.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include "../common/tool.h"
#include "protocol.h"


/* The global variable, used to store the protocol header. */
protocol_t proto = {0};

/* pack_proto_head:
 * Add the protocol header to the datas being sended.
 * @proto_type: the protocol type adding into the datas.
 * @major: the major version of the protocol.
 * @minor: the minor version of the protocol.
 * @data: the datas which are added the protocol.
 * @length: the length of "data".
 */
void pack_proto_head(unsigned short int proto_type, unsigned char major, 
                     unsigned char minor, unsigned char *data, size_t length)
{
  data[0] = (unsigned char)(proto_type % num1);
  data[1] = (unsigned char)(proto_type / num1);
  data[2] = major;
  data[3] = minor;
  data[4] = (unsigned char)(length % num1);
  data[5] = (unsigned char)(length / num1);
}
/*
void pack(int proto_type, unsigned char *data, size_t length)
{
  pack_proto_head(proto_type, 1, 0, data, length);
}
*/
/* unpack_proto_head:
* Unpack the protocol header from "data" into "proto".
* @data: the datas whick will be unpack.
* @proto: If proto is NULL, unpack the protocol header into the global variable
*         "proto". Or, unpack into the address space which "proto" pointing to.
* RETURN: return the type of the protocol.
*/
unsigned short int unpack_proto_head(unsigned char *data, protocol_t *proto)
{
  proto->proto_type = (unsigned short int)(data[1] * num1) + data[0];
  proto->major = data[2];
  proto->minor = data[3];
  proto->length = data[5] * num1 + data[4];
  return proto->proto_type;
}


/* send_data:
 * Append the protocol header whose protocol type is "proto_type" to "data",
 * and Send "data" whose length is "length" to "sockfd".
 * If "data" is NULL, or "length" is equal to 0, only send the protocol header.
 * @sockfd: a file description. It should be a TCP socket.
 * @proto_type: the protocol type.
 * @data: the datas whick will be sent.
 * @length: the length of "data".
 * RETURN: return the number of the bytes which have been sent, but it contain
 *         the protocol header. If failed, return -1.
 */
int send_data(int sockfd, unsigned short int proto_type, unsigned char *data,
              size_t length)
{
  //int i;
  ssize_t ret_w = 0;
  size_t len;
  /* Cache, used to send datas. */
  unsigned char data_send[SEND_BUF_SIZE + 7] = {0};

  /* If "data" is NULL, or "length" is equal 0, only send the protocol
     header. */
  if (data == NULL || length == 0){
    pack(proto_type, data_send, 0);
    ret_w = write(sockfd, data_send, 6);
    return ret_w;
    
  }

  /* Send the protocol header and the datas. */
  (SEND_BUF_SIZE > length) ? (len = length) : (len = SEND_BUF_SIZE);
  pack(proto_type, data_send, len);
  memcpy(data_send + 6, data, len);

  ret_w = write(sockfd, data_send, len + 6);
  return ret_w;
}

/* recv_data:
 * Read datas from "sockfd", then unpack the protocol header into "protos", and
 * place the datas into "data".
 * If "data" is NULL, or "length" is equal to 0, only receive the protocol header.
 * @sockfd: a file description. It should be a TCP socket.
 * @data: used to store the datas reading.
 * @protos: used to store the protocol header unpacked.
 * RETURN: return the number of the bytes of the datas read really. But it
 *         doesn't contain the size of the protocol header. If "data" is NULL,
 *         the remained datas will be discarded. If fail, return -1.
 */
int recv_data(int sockfd, unsigned char *data, protocol_t *protos)
{
  ssize_t ret_r = 0;
  protocol_t *protocol = NULL;
  /* Cache, used to read the protocol header. */
  unsigned char data_proto[7] = {0};
  size_t ret = 0;
  unsigned char data_recv[RECV_BUF_SIZE] = {0};
  
  if (protos == NULL){
    protocol = &proto;
  }
  else {
    protocol = protos;
  }

  if ((ret_r = read(sockfd, data_proto, 6)) < 6 ){
    return ret_r;
  }

  unpack(data_proto, protocol); 
   
  /* If "data" is NULL, Only read the protocol header. */
  if (data == NULL){
    if (protocol->length > 0)
      (void)read(sockfd, data_recv, protocol->length); 
    return ret_r;
  }
    
  if ((ret = read(sockfd, data, protocol->length)) < 0){
    return ret;
  }

  /* The return value contains the number of the protocol header. */
  return ret_r + ret;
}

/* sendto_data:
 * Append the protocol header whose protocol type is "proto_type" to "data",
 * and Send "data" whose length is "length" to the host which "destaddr"
 * represents through "sockfd".
 * @sockfd: a file description. It should be a UDP socket.
 * @proto_type: the protocol type.
 * @data: the datas whick will be sent.
 * @length: the length of "data".
 * @destaddr: the address which represents a host and a port.
 * @destlen: the number of the bytes of "address".
 * RETURN: return the number of the bytes which have been sent, but it contain
 *         the protocol header. If failed, return -1.
 */
int sendto_data(int sockfd, unsigned short int proto_type, unsigned char *data, 
                size_t length, const struct sockaddr *destaddr, socklen_t destlen)
{
  /* Cache, used to send datas. */
  unsigned char data_send[SEND_BUF_SIZE + 7] = {0};
  ssize_t len_w = 0;
  size_t len = (length < SEND_BUF_SIZE ? length : SEND_BUF_SIZE);
  int ret;

  if (destaddr == NULL || destlen <= (socklen_t)0)  return 0;
  if (data == NULL || len == 0){
    pack(proto_type, data_send, 0);
    len_w = sendto(sockfd, data_send, 6, 0, destaddr, destlen);
    return len_w;
  }

  pack(proto_type, data_send, len);
  memcpy(data_send + 6, data, len);

  if ((ret = sendto(sockfd, data_send, len + 6, 0, destaddr, destlen)) < 0){
     return -1;
  }
  
  return len_w + ret;
}

/* recvfrom_data:
 * Read datas from the host "addr" whose size is addrlen through "sockfd", then
 * unpack the protocol header into "protos", and place the datas into "data".
 * @sockfd: a file description. It should be a UDP socket.
 * @data: used to store the datas reading.
 * @addr: the address representing  the IP and the prot of the remote host.
 * @addrlen: the size of "addr".
 * @protos: used to store the protocol header unpacked.
 * RETURN: return the number of the bytes of the datas read really. But it
 *         contain the size of the protocol header.
 */
int recvfrom_data(int sockfd, unsigned char *data, struct sockaddr *addr, 
                  socklen_t *addrlen, protocol_t *protos)
{
  ssize_t ret = 0;
  protocol_t *protocol = NULL;
  unsigned char buf_recv[RECV_BUF_SIZE + 7] = {0};
  
  if (protos == NULL)  protocol = &proto;
  else                 protocol = protos;

  if ((ret = recvfrom(sockfd, buf_recv, RECV_BUF_SIZE + 7, 0, addr, addrlen)) < 6 )
    return ret; 

  unpack(buf_recv, protocol);
  if (data != NULL)  memcpy(data, buf_recv + 6, RECV_BUF_SIZE);
  return ret;
}
