/*
 * Copyright (c) 2012  Xie Gaofeng
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *     Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *     Neither the name of the <ORGANIZATION> nor the names of its contributors
 *     may be used to endorse or promote products derived from this software
 *     without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __PROTOCOL_H
#define __PROTOCOL_H

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

/* Define some protocol. */
/* REGISTER */
#define REGISTER_PROTO     (1000)
/* LOGINE */
#define LOGIN_PROTO        (1001)
/* THE HEARBEAT MECHANISM */
#define HEARTBEAT_PROTO    (1002)
/* BROATCAST */
#define BROAT_PROTO        (1003)
/* COMMUNICATE BETWEEN THE CLIENTS */
#define CLIENT_PROTO       (1004)


#define SEND_BUF_SIZE        (1024)
#define RECV_BUF_SIZE        SEND_BUF_SIZE
#define PROTO_HEADER_SIZE    (6)

/* a structure type, used to save the information of the protocol header. */
typedef struct _Protocol_t{
  unsigned short int proto_type;
  unsigned char major;
  unsigned char minor;
  unsigned int length;
}protocol_t;

/* Define two macros of pack_proto_head and unpack_proto_head. */
#define pack(type, data, length) pack_proto_head(type, 1, 0, data, length)
#define unpack(data, proto) unpack_proto_head(data, proto)

/* send_data:
 * Append the protocol header whose protocol type is "proto_type" to "data",
 * and Send "data" whose length is "length" to "sockfd".
 * If "data" is NULL, or "length" is equal to 0, only send the protocol header.
 * @sockfd: a file description. It should be a TCP socket.
 * @proto_type: the protocol type.
 * @data: the datas whick will be sent.
 * @length: the length of "data".
 * RETURN: return the number of the bytes which have been sent, but it contain
 *         the protocol header.
 */
int send_data(int sockfd, unsigned short int proto_type, unsigned char *data,
              size_t length);


/* recv_data:
 * Read datas from "sockfd", then unpack the protocol header into "protos", and
 * place the datas into "data".
 * If "data" is NULL, or "length" is equal to 0, only receive the protocol header.
 * @sockfd: a file description. It should be a TCP socket.
 * @data: used to store the datas reading.
 * @protos: used to store the protocol header unpacked.
 * RETURN: return the number of the bytes of the datas read really. But it
 *         doesn't contain the size of the protocol header. If "data" is NULL,
 *         the remained datas will be discarded.
 */
int recv_data(int sockfd, unsigned char *data, protocol_t *protos);

/* sendto_data:
 * Append the protocol header whose protocol type is "proto_type" to "data",
 * and Send "data" whose length is "length" to the host which "destaddr"
 * represents through "sockfd".
 * @sockfd: a file description. It should be a UDP socket.
 * @proto_type: the protocol type.
 * @data: the datas whick will be sent.
 * @length: the length of "data".
 * @destaddr: the address which represents a host and a port.
 * @destlen: the number of the bytes of "address".
 * RETURN: return the number of the bytes which have been sent, but it contain
 *         the protocol header.
 */
int sendto_data(int sockfd, unsigned short int proto_type, unsigned char *data,
                size_t length, const struct sockaddr *destaddr, socklen_t destlen);

/* recvfrom_data:
* Read datas from the host "addr" whose size is addrlen through "sockfd", then
* unpack the protocol header into "protos", and place the datas into "data".
* @sockfd: a file description. It should be a UDP socket.
* @data: used to store the datas reading.
* @addr: the address representing  the IP and the prot of the remote host.
* @addrlen: the size of "addr".
* @protos: used to store the protocol header unpacked.
* RETURN: return the number of the bytes of the datas read really. But it
*         contain the size of the protocol header.
*/
int recvfrom_data(int sockfd, unsigned char *data, struct sockaddr *addr, 
                  socklen_t *addrlen, protocol_t *protos);

#endif /*  __PROTOCOL_H  */
