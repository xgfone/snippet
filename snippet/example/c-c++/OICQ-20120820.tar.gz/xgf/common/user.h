

#ifndef __USER_H
#define __USER_H

#include <time.h>

/* a structure type, which the server use to save the registered user. */
/*
typedef struct user{
  unsigned char name[10];
  unsigned char password[10];
};
*/

/* a structure type, used to save the information of the online user. */
typedef struct user_on{
  unsigned int ip;
  unsigned char name[10];
  time_t time;
  //struct user_on *prev;
  //struct user_on *next;
}user_on;


/* compare_by_name:
 * Compare whether the two variables whose type is user_on are equal by name.
 * @user1 and @user2: a pointer pointing to the structure "user_on".
 * RETURN:
 *       If user1 is larger than user2, return a positive number.
 *       If user1 is equal to user2, return 0;
 *       If user1 is less than user2, return a negative number.
 */
int compare_by_name(user_on *user1, user_on *user2);

/* compare_by_ip:
 * Compare whether the two variables whose type is user_on are equal by IP.
 * @user1 and @user2: a pointer pointing to the structure "user_on".
 * RETURN:
 *       If user1 is larger than user2, return 1.
 *       If user1 is equal to user2, return 0;
 *       If user1 is less than user2, return -1.
 */
int compare_by_ip(user_on *user1, user_on *user2);


#endif /*  __USER_H  */
