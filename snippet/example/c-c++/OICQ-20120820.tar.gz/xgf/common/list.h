
#ifndef __XLIST_H
#define __XLIST_H
#include "user.h"

/* Define a structure type of double list. */
typedef struct _XList XList;
struct _XList{
  user_on *data;
  XList *prev;
  XList *next;
};

/* x_list_append:
* Append one node whose data is "data" into "list".
* @list: a list appended one node into.
* @data: the data of one new node.
* RETURN: the address of the first node of "list". If "list" is NULL, it will
*         update the address of the first node of "list". If fail, return NULL.
*/
XList *x_list_append(XList *list, user_on *data);

/* x_list_prepend:
* Insert one node whose data is "data" into the first location of "list".
* @list: a list prepended one node into.
* @data: the data of one new node.
* RETURN: the address of the first node of "list". If "list" is NULL, it will
*         update the address of the first node of "list". If fail, return NULL.
*/
XList *x_list_prepend(XList *list, user_on *data);

/* x_list_free:
* Release the node which "elem" points to.
* @elem: a pointer pointing to XList.
*/
void x_list_free(XList *elem);

/* x_list_free_full:
* Release all the node of "list".
* @list: a pointer pointing to a list whose type is XList.
*/
void x_list_free_full(XList *list);

XList *x_list_free_from_list(XList *list, XList *node);

/* x_list_find:
* Find the node which is equal to "data" according to the function "compare".
* @list: a pointer pointing to a list whose type is XList.
* @data: used to compare with the data of the node of "list".
* @compare: used to compare two variable,
*           if data1 is larger than data2, return a positive number;
*           if data1 is equal than data2, return 0;
*           if data1 is less than data2, return a negative.
* RETURN: If found, return the corresponding node. If not found, return NULL.
*/
XList *x_list_find(XList *list, user_on *data,
                   int (*compare)(user_on *data1, user_on *data2));

/* x_list_last:
 * Return the last node.
 * @list: a pointer pointing to a list whose type is XList.
 * RETURN: if "list" is NULL, return NULL; Or, return the last node.
 */
XList *x_list_last(XList *list);

/* x_list_prev:
 * Return the previous node of "node".
 * @node: a pointer pointing to a node of XList.
 * RETURN: return the pointer of the previous node of "node". If "node" is NULL, 
 *         return the first node. If "list" is NULL, return NULL.
 */
XList *x_list_next(XList *list, XList *node);


/* x_list_next:
 * Return the next node of "node".
 * @node: a pointer pointing to a node of XList.
 * RETURN: return the pointer of the next node of "node". If "node" is NULL, 
 *         return the last node. If "list" is NULL, return NULL. If "node" is
 *         equal to "list", return NULL.
 */
XList *x_list_prev(XList *list, XList *node);

#endif /* __XLIST_H  */
