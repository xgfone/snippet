

#include <string.h>
#include "user.h"

/* compare:
 * Compare whether the two variables whose type is user_on are equal.
 * @user1 and @user2: a pointer pointing to the structure "user_on".
 * RETURN:
 *       If user1 is larger than user2, return a positive number.
 *       If user1 is equal to user2, return 0;
 *       If user1 is less than user2, return a negative number.
 */
int compare_by_name(user_on *user1, user_on *user2)
{
  return strcmp((char *)(user1->name), (char *)(user2->name));
}

/* compare_by_ip:
 * Compare whether the two variables whose type is user_on are equal by IP.
 * @user1 and @user2: a pointer pointing to the structure "user_on".
 * RETURN:
 *       If user1 is larger than user2, return 1.
 *       If user1 is equal to user2, return 0;
 *       If user1 is less than user2, return -1.
 */
int compare_by_ip(user_on *user1, user_on *user2)
{
  if (user1->ip >  user2->ip)  return 1;
  if (user1->ip == user2->ip)  return 0;
  return -1;
}
