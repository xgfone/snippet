

#include <stdlib.h>
#include "list.h"
#include "user.h"

/* x_list_append:
 * Append one node whose data is "data" into "list".
 * @list: a list appended one node into.
 * @data: the data of one new node.
 * RETURN: the address of the first node of "list". If "list" is NULL, it will
 *         update the address of the first node of "list". If fail, return NULL.
 */
XList *x_list_append(XList *list, user_on *data)
{
  XList *new;
  XList *last;

  /* Don't change the "list". */
  if (data == NULL) return list;
  /* malloc one new node. */
  if ((new = (XList *)malloc(sizeof(XList))) == NULL) return NULL;
  /* malloc the space of "data" for the new node. */
  if ((new->data = (user_on *)malloc(sizeof(*data))) == NULL){
    free(new);
    return NULL;
  }
  *(new->data) = *data;
  new->next = NULL;

  /* The new node is the first node. */
  if (list == NULL){
    new->prev = NULL;
    return new;
  }

  last = x_list_last(list);
  last->next = new;
  new->prev = last;
  return list;
}

/* x_list_prepend:
* Insert one node whose data is "data" into the first location of "list".
* @list: a list prepended one node into.
* @data: the data of one new node.
* RETURN: the address of the first node of "list". If "list" is NULL, it will
*         update the address of the first node of "list". If fail, return NULL.
*/
XList *x_list_prepend(XList *list, user_on *data)
{
  XList *new;

  /* Don't change the "list". */
  if (data == NULL) return list;
  /* malloc one new node. */
  if ((new = (XList *)malloc(sizeof(XList))) == NULL) return NULL;
  /* malloc the space of "data" for the new node. */
  if ((new->data = (user_on *)malloc(sizeof(*data))) == NULL){
    free(new);
    return NULL;
  }
  *(new->data) = *data;
  new->prev = NULL;

  if (list == NULL){
    new->next = NULL;
    return new;
  }

  new->next = list;
  list->prev = new;
  return new;
}

/* x_list_free:
 * Release the node which "elem" points to.
 * @elem: a pointer pointing to XList.
 */
void x_list_free(XList *elem)
{
  free(elem->data);
  free(elem);
}

/* x_list_free_full:
* Release all the node of "list".
* @list: a pointer pointing to a list whose type is XList.
*/
void x_list_free_full(XList *list)
{
  XList *p = list;
  while (list != NULL){
    p = list;
    list = list->next;
    x_list_free(p);
  }
}

/*  
 */
XList *x_list_free_from_list(XList *list, XList *node)
{
  if (node == NULL || list == NULL) return list;

  /* free the first node. */
  if (node == list){
    list = node->next;
    if (list != NULL)  list->prev = NULL;
    /* free the node really. */
    x_list_free(node);
    return list;
  }
  else if (node->next != NULL){  /* free the non-first and non-last node. */
    node->prev->next = node->next;
    node->next->prev = node->prev;
  }
  else { /* free the last node. */
    node->prev->next = NULL;
  }
  
  /* free the node really. */
  x_list_free(node);
  return list;
}


/* x_list_find:
 * Find the node which is equal to "data" according to the function "compare".
 * @list: a pointer pointing to a list whose type is XList.
 * @data: used to compare with the data of the node of "list".
 * @compare: used to compare two variable,
 *           if data1 is larger than data2, return a positive number;
 *           if data1 is equal than data2, return 0;
 *           if data1 is less than data2, return a negative.
 * RETURN: If found, return the corresponding node. If not found, return NULL.
 */
XList *x_list_find(XList *list, user_on *data, 
                   int (*compare)(user_on *data1, user_on *data2))
{
  XList *p = list;
  if (data == NULL || list == NULL) return NULL;
  while (p != NULL){
    if (compare(p->data, data) == 0) return p;
    p = p->next;
  }
  return NULL;
}

/* x_list_last:
 * Return the last node.
 * @list: a pointer pointing to a list whose type is XList.
 * RETURN: if "list" is NULL, return NULL; Or, return the last node.
 */
XList *x_list_last(XList *list)
{
  XList *p = list;
  if (list == NULL) return NULL;
  while (p->next != NULL){
    p = p->next;
  }
  return p;
}

/* x_list_next:
 * Return the next node of "node".
 * @node: a pointer pointing to a node of XList.
 * RETURN: return the pointer of the next node of "node". If "node" is NULL, 
 *         return the first node. If "list" is NULL, return NULL.
 */
XList *x_list_next(XList *list, XList *node)
{
  if (list == NULL) return NULL;
  if (node == NULL) return list;
  return node->next;  
}

/* x_list_prev:
 * Return the previous node of "node".
 * @node: a pointer pointing to a node of XList.
 * RETURN: return the pointer of the previous node of "node". If "node" is NULL, 
 *         return the last node. If "list" is NULL, return NULL. If "node" is
 *         equal to "list", return NULL.
 */
XList *x_list_prev(XList *list, XList *node)
{
  if (list == NULL) return NULL;
  if (node == list) return NULL;
  if (node == NULL) return x_list_last(list);
  return node->prev;
}
