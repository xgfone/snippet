/**********************************************************************
 *********************************  说明  ******************************
(1)修改的结构体：
	struct daoli_flow 和 struct daoli_flow_table 两个结构体
	注：struct daoli_sw_flow 仅添加了一个字段 flow，并不影响以前的操作，此字段仅在操作
	流表时使用，可以忽略它，就当它不存在。

(2)去除的接口：
	daoli_flow_table_search

(3)保留不变的接口及实现：
	daoli_flow_lookup
	daoli_flow_lookup_icmp
	daoli_nat_flow_table_lookup
	注：由于上述函数使用了 daoli_flow_table_find_flow 函数，而此函数的接口与语义又没有
	发生变化，故上述函数的接口和实现均没有被修改。

	除了上述接口，还有以下接口未改变：
	daoli_flow_key_hash
	daoli_flow_key_hash_R
	daoli_flow_key_hash_icmp
	注：这些接口与生成 32位key 有关，与流表的操作无关，故无需改变。

(4)新的或被改变的接口有：
	daoli_init_flow_table
	daoli_clean_flow_table
	daoli_flow_table_insert
	daoli_flow_table_delete
	daoli_flow_table_delete_by_key
	daoli_flow_table_find_flow

	daoli_flow_table_init
	daoli_flow_table_exit


测试说明：
	（0）在 CentOS 6.5（2.6.32-431.20.5.el6.x86_64） 下测试
	（1）编译内核模块 test_flow.ko
	（2）加载内核模块： insmod test_flow.ko
	（3）此时会有测试日志输出（见下方）
	（4）卸载内核模块： rmmod test_flow

测试结果：
	Jul 29 23:21:42 debug02 kernel: Daoli(Init)Loading Module ......
	Jul 29 23:21:42 debug02 kernel: Daoli(init_flow_table): Finished to initialize the flow table
	Jul 29 23:21:42 debug02 kernel: Daoli(test): Adding a flow
	Jul 29 23:21:42 debug02 kernel: Daoli(test): Finding a flow
	Jul 29 23:21:42 debug02 kernel: Daoli(test): Find a flow(daoli_sw_flow): flag(11)  flow_key(22)
	Jul 29 23:21:42 debug02 kernel: Daoli(test): Deleting a flow
	Jul 29 23:21:42 debug02 kernel: Daoli(test): Finding a flow again
	Jul 29 23:21:42 debug02 kernel: Daoli(test): Failed to find a flow, according to the key, 22
	Jul 29 23:21:42 debug02 kernel: Daoli(Init): Finished to load
	Jul 29 23:21:47 debug02 kernel: Daoli(Exit): Unloading module ......
	Jul 29 23:21:47 debug02 kernel: Daoli(clean_flow_table): Finished to clean the flow table
	Jul 29 23:21:47 debug02 kernel: Daoli(Exit): Finished to unload

根据以上输出，和预料中的一致，暂时没发现什么错误；不过，还需要大量的测试才能说明没有问题。

*************************************************************************/

////////////// 头文件部分
#include <linux/types.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/rculist.h>

// 这个结构是临时测试用的
// 注意：struct daoli_sw_flow 中除了 flow 字段外，不能有动态分配的内存/字段
struct daoli_sw_flow {
	//// 为了测试方便，省略一部分字段，在正式使用时，请把其他的字段添加进来。注：此省略的字段不能是动态分配的
	u32 flag;
	u32 flow_key;
	struct daoli_flow *flow;	// 新添加的字段，为了方便找到 struct daoli_flow，就像OVS中通过VPORT来找到DP一样
};

struct daoli_flow {
	struct daoli_sw_flow * sw_flow;
	u32 flow_key;
	struct hlist_node hash_node;	// 这个流表的私有字段，无需关心
};

#define DAOLI_FLOW_HASH_BACKETS	1024
struct daoli_flow_table {
	struct hlist_head *flows;
	struct rcu_head rcu;	// 这个字段是以前陈山加的，不知道做什么用，估计是用RCU机制来保护流表结构体。这里未使用，暂时保留
};

// 基于哈希链表的流表的公共操作
extern int daoli_init_flow_table(struct daoli_flow_table *table);
extern void daoli_clean_flow_table(struct daoli_flow_table *table);
extern void daoli_flow_table_insert(struct daoli_flow_table *table, struct daoli_flow *flow);
extern void daoli_flow_table_delete(struct daoli_flow *flow);
extern void daoli_flow_table_delete_by_key(struct daoli_flow_table *table, u32 key);
extern struct daoli_sw_flow* daoli_flow_table_find_flow(struct daoli_flow_table *table, u32 key);

// 为了方便，又定义了两个函数：初始化函数和清理函数
extern int daoli_flow_table_init(void);
extern void daoli_flow_table_exit(void);

extern struct daoli_flow_table daoli_flow_table;

///////////////////////////////////////////////////////////////////////////

///////////// 实现部分

// 初始化流表
int daoli_init_flow_table(struct daoli_flow_table *table)
{
	size_t i;

	if (!table)
		return -1;

	table->flows = kmalloc(sizeof(struct hlist_head) * DAOLI_FLOW_HASH_BACKETS, GFP_KERNEL);
	if (!table->flows) {
		pr_info("Daoli(init_flow_table): Failed to initialize the flow table\n");
		return -1;
	}

	for (i=0; i<DAOLI_FLOW_HASH_BACKETS; ++i)
		INIT_HLIST_HEAD(&table->flows[i]);

	pr_info("Daoli(init_flow_table): Finished to initialize the flow table\n");

	return 0;
};

// 清理流表
void daoli_clean_flow_table(struct daoli_flow_table *table)
{
	size_t i;
	struct hlist_head *head;
	struct daoli_flow *flow;

	rcu_read_lock();
	for (i=0; i<DAOLI_FLOW_HASH_BACKETS; ++i) {
		head = &table->flows[i];
		while (!hlist_empty(head)) {
			flow = hlist_entry(rcu_dereference(head->first), struct daoli_flow, hash_node);
			daoli_flow_table_delete(flow);
		}
	}
	rcu_read_unlock();

	pr_info("Daoli(clean_flow_table): Finished to clean the flow table\n");
}

// 辅助函数（对外不可见），为了找到哈希链表中的链表头
static struct hlist_head *_daoli_flow_hash_bucket(const struct daoli_flow_table *table, u32 key)
{
	return &table->flows[key & (DAOLI_FLOW_HASH_BACKETS - 1)];
}

// 将一个流 flow 插入到流表 table 中
void daoli_flow_table_insert(struct daoli_flow_table *table, struct daoli_flow *flow)
{
	struct hlist_head *head;

	head = _daoli_flow_hash_bucket(table, flow->flow_key);
	hlist_add_head_rcu(&flow->hash_node, head);
}

// 从流表中删除流 flow
void daoli_flow_table_delete(struct daoli_flow *flow)
{
	hlist_del_rcu(&flow->hash_node);
	kfree(flow->sw_flow);
	kfree(flow);
}

// 根据键 key，将从一个流中从流表 table 中删除
void daoli_flow_table_delete_by_key(struct daoli_flow_table *table, u32 key)
{
	struct daoli_sw_flow *sw_flow;

	sw_flow = daoli_flow_table_find_flow(table, key);
	daoli_flow_table_delete(sw_flow->flow);
}

// 根据键 key，从流表 tabel 中查找一个流
// 注（高峰）：原本返回 struct daoli_flow *，但为了原来的接口一致，故返回 struct daoli_sw_flow * 指针
struct daoli_sw_flow* daoli_flow_table_find_flow(struct daoli_flow_table *table, u32 key)
{
	struct hlist_head *head;
	struct hlist_node *node;
	struct daoli_flow *flow;

	head = _daoli_flow_hash_bucket(table, key);
	rcu_read_lock();
	hlist_for_each_entry_rcu(flow, node, head, hash_node) {
		if (flow->flow_key == key) {
			return flow->sw_flow;
		}
	}
	rcu_read_unlock();

	return NULL;
}

////////////// TEST 测试
struct daoli_flow_table daoli_flow_table = {NULL};

void daoli_test(void)
{
	struct daoli_sw_flow *sw_flow;
	struct daoli_flow *flow;
	struct daoli_sw_flow *p;
	u32 key = 22;		// For testing

	sw_flow = kmalloc(sizeof(struct daoli_sw_flow), GFP_KERNEL);
	if (!sw_flow) {
		pr_info("Daoli(test): Failed to allocate daoli_sw_flow\n");
		return;
	}

	flow = kmalloc(sizeof(struct daoli_flow), GFP_KERNEL);
	if (!flow) {
		pr_info("Daoli(test): Failed to allocate daoli_flow\n");
		return;
	}

	sw_flow->flag = 11;
	sw_flow->flow_key = key;
	sw_flow->flow = flow;

	flow->sw_flow = sw_flow;
	flow->flow_key = key;

	// Add a flow into the flow table
	pr_info("Daoli(test): Adding a flow\n");
	daoli_flow_table_insert(&daoli_flow_table, flow);

	// Find a flow from the flow table
	pr_info("Daoli(test): Finding a flow\n");
	p = daoli_flow_table_find_flow(&daoli_flow_table, key);
	if (!p) {
		pr_info("Daoli(test): Failed to find a flow, according to the key, %u\n", key);
		return;
	}

	// Print a flow
	pr_info("Daoli(test): Find a flow(daoli_sw_flow): flag(%u)  flow_key(%u)\n", p->flag, p->flow_key);

	/*
	// Delete a flow from the flow table
	pr_info("Daoli(test): Deleting a flow\n");
	//daoli_flow_table_delete(p->flow);
	daoli_flow_table_delete_by_key(&daoli_flow_table, key);

	// Find secondly
	pr_info("Daoli(test): Finding a flow again\n");
	p = daoli_flow_table_find_flow(&daoli_flow_table, key);
	if (!p) {
		pr_info("Daoli(test): Failed to find a flow, according to the key, %u\n", key);
		return;
	}
	*/
}


int daoli_flow_table_init(void)
{
	int ret;

	pr_info("Daoli(Init)Loading Module ......\n");

	ret = daoli_init_flow_table(&daoli_flow_table);
	if (ret < 0)
		return ret;

	daoli_test();

	pr_info("Daoli(Init): Finished to load\n");

	return ret;
}

void daoli_flow_table_exit(void)
{
	pr_info("Daoli(Exit): Unloading module ......\n");
	daoli_clean_flow_table(&daoli_flow_table);
	pr_info("Daoli(Exit): Finished to unload\n");
}

module_init(daoli_flow_table_init);
module_exit(daoli_flow_table_exit);

MODULE_DESCRIPTION("Test Flow Hash List");
MODULE_LICENSE("GPL");
MODULE_AUTHOR("xgfone <xgfone@126.com>");
